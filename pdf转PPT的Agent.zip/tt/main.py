import os
import argparse
from pdf_parser import PdfParser
from llm_summarizer import LlmSummarizer
from ppt_generator import PptGenerator

def main(pdf_path, output_name):

    print(f"Starting conversion for: {pdf_path}")

    # --- 1. 解析pdf ---
    print("Step 1: Parsing PDF to extract text, images, and tables...")
    if not os.path.exists(pdf_path):
        print(f"Error: The file '{pdf_path}' does not exist.")
        return
        
    parser = PdfParser(pdf_path)
    text_content = parser.extract_text()
    
    # 设置输出位置和名字
    pdf_filename = os.path.splitext(os.path.basename(pdf_path))[0]
    asset_output_dir = f"output/{pdf_filename}_assets"
    
    assets = parser.extract_images_and_tables(output_dir=asset_output_dir)
    parser.close()
    
    if not text_content.strip():
        print("Error: No text could be extracted from the PDF. Cannot proceed.")
        return

    print(f"Successfully extracted {len(text_content)} characters of text.")
    print(f"Found and saved {len(assets)} assets (images/tables) to '{asset_output_dir}'.")

    # --- 用LLM总结 ---
    print("\nStep 2: Summarizing text with AI, analyzing tables and associating assets...")
    summarizer = LlmSummarizer()
    summary_json = summarizer.generate_summary_json(text_content, assets)
    
    if not summary_json or not summary_json.get("slides"):
        print("Error: Failed to generate a summary. Aborting.")
        return
        
    print("AI summary and outline generated successfully.")

    # --- 生成PPT ---
    print("\nStep 3: Generating PowerPoint presentation with integrated assets...")
    ppt_generator = PptGenerator(summary_json, asset_output_dir)
    
    output_filename = f"output/{output_name}.pptx"
    ppt_generator.create_presentation(output_filename)
    
    print(f"\n--- All Done! ---")
    print(f"Presentation saved as: {output_filename}")


if __name__ == '__main__':

    cli_parser = argparse.ArgumentParser(description="Convert a PDF paper to a PowerPoint presentation.")
    cli_parser.add_argument("pdf_path", type=str, help="The full path to the input PDF file.")
    cli_parser.add_argument("--output", type=str, default="presentation_final", help="The desired name for the output PPTX file (without extension).")
    
    args = cli_parser.parse_args()
    
    main(args.pdf_path, args.output)
