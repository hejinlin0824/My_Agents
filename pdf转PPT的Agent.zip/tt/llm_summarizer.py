import os
import json
from langchain_community.llms import Tongyi 
from langchain_core.prompts import PromptTemplate 
from langchain.chains import LLMChain
from dotenv import load_dotenv 

class LlmSummarizer:
    """
    一个使用大语言模型（LLM）来总结文本并生成PPT大纲的类。
    """
    def __init__(self):
        """
        初始化LlmSummarizer。
        它会加载环境变量并初始化通义千问模型。
        """
        # 加载.env文件中的环境变量（特别是API密钥）
        load_dotenv()
        # 检查API密钥是否已成功加载
        if not os.getenv("DASHSCOPE_API_KEY"):
            raise ValueError("在.env文件中未找到DASHSCOPE_API_KEY。")
            
        # 初始化通义千问模型，这里使用qwen-turbo模型
        self.llm = Tongyi(model='qwen-turbo')

    def generate_summary_json(self, text_content, assets):
        """
        生成结构化的JSON格式摘要，该摘要将用于创建PPT。
        此方法会分析文本内容和资产（特别是表格数据），以生成富有洞察力的描述。
        :param text_content: 从PDF提取的原始文本。
        :param assets: 一个包含图片和表格信息的资产列表。
        :return: 一个包含PPT大纲的JSON对象。
        """
        # --- 1. 准备给模型的资产清单 ---
        # 将资产列表格式化为人类可读的字符串，其中包含表格的数据预览
        asset_descriptions = []
        for asset in assets:
            filename = os.path.basename(asset["path"])
            description = f"- {filename} (类型: {asset['type']}"
            if asset['type'] == 'table':
                # 将表格数据转换为简单的字符串格式，只预览前3行
                table_preview = "\n  ".join([" | ".join(map(str, row)) for row in asset['data'][:3]])
                description += f", 数据预览:\n  {table_preview}"
            description += ")"
            asset_descriptions.append(description)
        
        asset_list_str = "\n".join(asset_descriptions)

        # --- 2. 定义提示模板（Prompt Template） ---
        template = """
        你是一位顶级的演示文稿制作专家和数据分析师。你的任务是根据一篇研究论文的文本和提取的视觉资产（图片、表格），生成一份结构化的、富有洞察力的JSON摘要，用于创建PowerPoint。
        **请务必使用简体中文来生成所有内容。**

        你已获得论文的全文，以及一个详细的资产列表。对于表格，你还获得了其内部的结构化数据。

        **核心任务：**
        1.  创建以"slides"为根键的JSON结构。每个幻灯片对象必须有"title"和"content"（要点列表）。
        2.  智能地将最相关的资产（图片或表格）分配到幻灯片中，通过"asset"键指定其**原始文件名**。
        3.  **【关键指令】** 当你在幻灯片中引用一个**表格**时，除了根据正文正常生成要点外，请**额外增加一个要点**来总结你对表格数据的洞察。这个新增的要点应该以“此表格显示...”或类似的引导语开头。确保正文的要点和表格的洞察**同时存在**于"content"列表中。
        4.  一定要完整，不能省略内容或者其他必要信息。
        这是论文文本：
        ---
        {text}
        ---

        这是可用的资产列表（包含表格数据预览）：
        ---
        {assets}
        ---

        请提供干净的JSON格式输出。
        JSON结构示例：
        {{
          "slides": [
            {{
              "title": "引言",
              "content": [
                "关于引言的要点1...",
                "关于引言的要点2..."
              ]
            }},
            {{
              "title": "研究方法",
              "content": [
                "我们使用了一种特定的分析方法。",
                "流程如下图所示。"
              ],
              "asset": "page3_img1.png"
            }},
            {{
              "title": "研究成果",
              "content": [
                "关键成果总结在下表中。",
                "此表格显示，A组的成功率（85%）显著高于B组（62%）。"
              ],
              "asset": "page5_table0.png"
            }}
          ]
        }}
        """
        
        # --- 3. 创建并运行LLM链 ---
        prompt = PromptTemplate(template=template, input_variables=["text", "assets"])
        chain = LLMChain(llm=self.llm, prompt=prompt)
        
        # 运行链，将文本内容和资产清单传递给模型
        raw_response = chain.run(text=text_content, assets=asset_list_str)
        
        # --- 4. 清理和解析模型的响应 ---
        try:
            # 模型有时可能会在JSON响应外包裹markdown代码块（```json ... ```），需要移除，这我报过错
            if "```json" in raw_response:
                clean_response = raw_response.split("```json")[1].split("```")[0].strip()
            else:
                clean_response = raw_response.strip()
            
            # 将清理后的字符串解析为JSON对象
            summary_json = json.loads(clean_response)
            return summary_json
        except (json.JSONDecodeError, IndexError) as e:
            # 如果解析失败，打印错误并返回一个包含错误信息的JSON
            print(f"解析LLM响应的JSON时出错: {e}")
            print(f"原始响应是: \n{raw_response}")
            return {"slides": [{"title": "错误", "content": ["无法从LLM解析摘要。"]}]}

# --- 主程序入口，用于测试 ---
if __name__ == '__main__':
    summarizer = LlmSummarizer()
    
    # 用于测试的虚拟文本
    dummy_text = """
    本研究旨在介绍一种新颖的机器学习模型解释框架。
    我们的方法论包含一个两阶段过程。首先，我们使用一个代理模型来近似一个复杂黑盒模型的行为。
    其次，我们应用SHAP（SHapley Additive exPlanations）到代理模型上，以获得特征重要性得分。
    结果表明，与现有方法相比，我们的方法提供了更一致和准确的解释。
    我们得出结论，该框架是向透明化人工智能迈出的重要一步。
    """
    
    # 用于测试的虚拟资产列表
    dummy_assets_structured = [
        {"type": "image", "path": "page2_img1.png"},
        {"type": "table", "path": "page4_table0.png", "data": [["指标", "数值"], ["准确率", "0.95"]]}
    ]
    # 生成摘要
    summary_data = summarizer.generate_summary_json(dummy_text, dummy_assets_structured)
    
    print("--- 生成的PPT摘要 (JSON) ---")
    print(json.dumps(summary_data, indent=2, ensure_ascii=False))

    # 将测试输出保存到文件以便检查
    with open("output/test.json", "w", encoding="utf-8") as f:
        json.dump(summary_data, f, indent=2, ensure_ascii=False)
    print("\n测试摘要已保存到 output/test.json")
