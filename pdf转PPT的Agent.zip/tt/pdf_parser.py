# 导入所需的库
import fitz  # PyMuPDF库，用于处理PDF文件
import os    # 用于操作系统相关的功能，如文件路径操作
from PIL import Image # Python Imaging Library，用于处理图片

class PdfParser:
    """
    一个用于解析PDF文件的类。
    它可以提取文本、图片和表格。
    """
    def __init__(self, pdf_path):
        """
        初始化PdfParser对象。
        :param pdf_path: PDF文件的路径。
        """
        # 检查文件是否存在，如果不存在则抛出异常
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"文件 {pdf_path} 未找到。")
        self.pdf_path = pdf_path
        # 使用fitz库打开PDF文件
        self.doc = fitz.open(pdf_path)

    def extract_text(self):
        """
        从PDF中提取所有文本内容。
        :return: 包含所有页面文本的字符串。
        """
        text = ""
        # 遍历PDF的每一页
        for page in self.doc:
            # 获取当前页的文本并追加到总文本中
            text += page.get_text()
        return text

    def _is_likely_text(self, page, bbox):
        """
        检查一个给定的边界框区域是否更可能是文本而不是一个真实的图片。
        这是一种启发式方法，用于过滤掉被错误识别为图片的文本块（例如，复杂的公式或标题）。
        :param page: 当前PDF页面对象。
        :param bbox: 图片的边界框（bounding box）。
        :return: 如果该区域内文本覆盖率超过50%，则返回True，否则返回False。
        """
        # 获取与图片边界框相交的文本块
        text_blocks = page.get_text("dict", clip=bbox)["blocks"]
        if not text_blocks:
            return False
        
        # 计算边界框内所有文本的总面积
        text_area = 0
        for block in text_blocks:
            for line in block["lines"]:
                for span in line["spans"]:
                    # span是具有相同字体属性的连续字符串
                    r = fitz.Rect(span["bbox"])
                    text_area += r.width * r.height
                    
        # 计算图片边界框的总面积
        bbox_area = (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])
        if bbox_area == 0:
            return True # 避免除以零错误

        # 如果文本覆盖率超过一个阈值（这里是50%），则认为它可能是文本
        return (text_area / bbox_area) > 0.5

    def extract_images_and_tables(self, output_dir="output/assets"):
        """
        从PDF中提取图片和表格。
        对于表格，它会同时保存为图片并提取其结构化数据。
        :param output_dir: 保存提取出的图片和表格截图的目录。
        :return: 一个包含所有提取出的资产信息的列表。每个资产是一个字典。
        """
        # 如果输出目录不存在，则创建它
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        assets = [] # 用于存储所有提取的资产
        # 遍历PDF的每一页
        for page_num in range(len(self.doc)):
            page = self.doc[page_num]
            
            # --- 1. 高级图片提取 ---
            image_list = page.get_images(full=True)
            for img_index, img in enumerate(image_list):
                try:
                    # 获取图片的边界框
                    bbox = page.get_image_bbox(img)
                except Exception as e:
                    print(f"无法获取第 {page_num+1} 页图片的边界框: {e}")
                    continue

                # 过滤器1：过滤掉尺寸过小的图片
                if bbox.width < 100 or bbox.height < 100: continue
                # 过滤器2：使用文本密度过滤器，避免将纯文本块当作图片
                if self._is_likely_text(page, bbox):
                    print(f"跳过第 {page_num+1} 页的图片，因为它可能是一个文本块。")
                    continue

                # 提取图片数据
                xref = img[0]
                base_image = self.doc.extract_image(xref)
                # 定义图片文件名和路径
                image_filename = f"page{page_num+1}_img{img_index}.{base_image['ext']}"
                image_path = os.path.join(output_dir, image_filename)
                
                # 将图片数据写入文件
                with open(image_path, "wb") as f:
                    f.write(base_image["image"])
                
                # 将图片信息添加到资产列表
                assets.append({"type": "image", "path": image_path})

            # --- 2. 表格提取（图片 + 数据） ---
            tables = page.find_tables()
            for table_index, table in enumerate(tables):
                # 获取表格的边界框，并将其渲染成一张图片
                bbox = table.bbox
                pix = page.get_pixmap(clip=bbox, dpi=300)
                table_filename = f"page{page_num+1}_table{table_index}.png"
                table_path = os.path.join(output_dir, table_filename)
                pix.save(table_path)
                
                # 从表格中提取结构化的文本数据
                table_data = table.extract()
                
                # 将表格信息（图片路径和结构化数据）添加到资产列表
                assets.append({
                    "type": "table",
                    "path": table_path,
                    "data": table_data,
                    "page": page_num + 1
                })

        return assets

    def close(self):
        """关闭PDF文档，释放资源。"""
        self.doc.close()

# --- 主程序入口，用于测试 ---
if __name__ == '__main__':
    # 如果测试PDF不存在，则创建一个简单的PDF用于演示
    if not os.path.exists("test.pdf"):
        print("正在创建一个用于演示的 test.pdf 文件...")
        doc = fitz.open()
        page = doc.new_page()
        page.insert_text((50, 72), "这是一个测试PDF文档。")
        page.insert_text((50, 92), "它包含一些文本，我们将假装它有图片和表格。")
        doc.save("test.pdf")
        doc.close()

    # 初始化解析器
    parser = PdfParser("test.pdf")
    
    print("--- 提取的文本 ---")
    text_content = parser.extract_text()
    print(text_content[:500]) # 打印前500个字符
    
    print("\n--- 提取的图片和表格 ---")
    # 提取所有资产
    extracted_assets = parser.extract_images_and_tables()
    if extracted_assets:
        for asset in extracted_assets:
            print(f"找到资产: {asset['path']} (类型: {asset['type']})")
            # 如果是表格，则预览其第一行数据
            if asset['type'] == 'table':
                print("  表格数据预览:", asset['data'][0])
    else:
        print("在PDF中未找到大型图片或表格。")
        
    # 关闭文档
    parser.close()
