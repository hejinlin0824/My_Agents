您好，只用在这个目录下运行命令：
python main.py '测试pdf文件路径'