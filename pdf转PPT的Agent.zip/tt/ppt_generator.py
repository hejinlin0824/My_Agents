# 导入所需的库
from pptx import Presentation # 用于创建和操作PPT文件
from pptx.util import Inches, Pt # 用于处理尺寸单位（英寸和磅）
import os

class PptGenerator:
    """
    一个用于根据结构化数据生成PowerPoint演示文稿的类。
    """
    def __init__(self, summary_data, asset_dir):
        """
        初始化PptGenerator。
        :param summary_data: 包含PPT大纲的JSON对象。
        :param asset_dir: 存放图片和表格截图等资产的目录。
        """
        self.summary = summary_data
        self.asset_dir = asset_dir
        self.prs = Presentation() # 创建一个新的PPT演示文稿对象
        # 定义常用的幻灯片布局
        self.title_slide_layout = self.prs.slide_layouts[0] # 标题幻灯片布局
        self.title_and_content_layout = self.prs.slide_layouts[1] # 标题和内容布局
        self.blank_layout = self.prs.slide_layouts[6] # 空白布局，用于完全自定义

    def create_presentation(self, output_filename="presentation.pptx"):
        """
        创建完整的演示文稿并保存。
        :param output_filename: 输出的PPT文件名。
        """
        self._create_title_slide() # 创建标题页
        self._create_content_slides() # 创建内容页
        
        # 确保输出目录存在
        output_dir = os.path.dirname(output_filename)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        
        # 保存PPT文件
        self.prs.save(output_filename)
        print(f"演示文稿已保存为 {output_filename}")

    def _create_title_slide(self):
        """创建演示文稿的第一页（标题页）。"""
        slide = self.prs.slides.add_slide(self.title_slide_layout)
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        
        # 使用大纲中第一张幻灯片的标题作为PPT的主标题
        if self.summary.get('slides'):
            title.text = self.summary['slides'][0].get('title', "演示文稿标题")
        else:
            title.text = "PDF生成演示文稿"
            
        subtitle.text = "由AI Agent生成"

    def _add_text_box(self, slide, text_content, left, top, width, height):
        """
        在幻灯片上添加并格式化一个文本框。
        :param slide: 要添加文本框的幻灯片对象。
        :param text_content: 要写入的文本内容（可以是字符串或列表）。
        :param left, top, width, height: 文本框的位置和尺寸。
        :return: 创建的文本框形状对象。
        """
        txBox = slide.shapes.add_textbox(left, top, width, height)
        tf = txBox.text_frame
        tf.word_wrap = True # 允许自动换行
        tf.clear() # 清除默认文本
        
        # 如果内容是列表，则逐条添加为段落
        if isinstance(text_content, list):
            for point in text_content:
                p = tf.add_paragraph()
                p.text = point
                p.level = 0
        else: # 如果是字符串，则直接添加
            p = tf.add_paragraph()
            p.text = str(text_content)
            p.level = 0
        return txBox

    def _add_picture_scaled(self, slide, asset_path, left, top, max_width, max_height):
        """
        在幻灯片上添加一张图片，并按比例缩放以适应指定区域。
        :param slide: 要添加图片的幻灯片对象。
        :param asset_path: 图片文件的路径。
        :param left, top: 图片区域的左上角坐标。
        :param max_width, max_height: 图片可占用的最大宽度和高度。
        """
        try:
            from PIL import Image
            # 使用Pillow库获取图片的原始尺寸
            with Image.open(asset_path) as img:
                width, height = img.size
            
            aspect_ratio = width / height # 计算宽高比
            
            # 根据最大宽度计算缩放后的尺寸
            scaled_width = max_width
            scaled_height = scaled_width / aspect_ratio

            # 如果计算出的高度超过了最大高度，则以最大高度为基准重新计算宽度
            if scaled_height > max_height:
                scaled_height = max_height
                scaled_width = scaled_height * aspect_ratio
            
            # 将图片在其分配的区域内居中放置
            final_left = left + (max_width - scaled_width) / 2
            final_top = top + (max_height - scaled_height) / 2

            # 在幻灯片上添加图片
            slide.shapes.add_picture(asset_path, final_left, final_top, 
                                    width=scaled_width, height=scaled_height)
        except Exception as e:
            print(f"无法添加或缩放资产 {asset_path}: {e}")

    def _create_content_slides(self):
        """
        使用动态、无重叠的布局创建所有内容幻灯片。
        """
        for slide_data in self.summary.get('slides', []):
            # 使用空白布局以获得完全的控制权
            slide = self.prs.slides.add_slide(self.blank_layout)
            
            # 添加并格式化标题
            title_shape = slide.shapes.add_textbox(Inches(0.5), Inches(0.2), Inches(9), Inches(0.8))
            title_shape.text_frame.text = slide_data.get('title', '无标题')
            title_p = title_shape.text_frame.paragraphs[0]
            title_p.font.bold = True
            title_p.font.size = Pt(28)

            content = slide_data.get('content', [])
            asset_filename = slide_data.get('asset')
            asset_path = os.path.join(self.asset_dir, asset_filename) if asset_filename else None

            # --- 动态布局逻辑 ---
            top_margin = Inches(1.2)
            left_margin = Inches(0.5)
            right_margin = Inches(0.5)
            slide_width = self.prs.slide_width - left_margin - right_margin
            slide_height = self.prs.slide_height - top_margin - Inches(0.5)

            if asset_filename and os.path.exists(asset_path):
                # --- 场景一：图文并茂的幻灯片 ---
                # 简单地将页面分为左右两半（50/50），可以根据需要实现更复杂的逻辑
                text_width = slide_width * 0.5
                image_width = slide_width * 0.5
                
                # 在左侧放置文本框
                self._add_text_box(slide, content, left_margin, top_margin, text_width, slide_height)
                
                # 在右侧放置图片
                self._add_picture_scaled(slide, asset_path, left_margin + text_width, top_margin, image_width, slide_height)
            else:
                # --- 场景二：纯文本幻灯片 ---
                # 文本框占据整个可用区域
                self._add_text_box(slide, content, left_margin, top_margin, slide_width, slide_height)

# --- 主程序入口，用于测试 ---
if __name__ == '__main__':
    # 用于测试新结构的虚拟数据
    dummy_summary_with_assets = {
      "slides": [
        {"title": "论文主标题", "content": ["这是核心主题。"]},
        {
          "title": "引言", 
          "content": ["关于引言的要点1。", "关于引言的要点2。"]
        },
        {
          "title": "研究方法", 
          "content": ["我们使用了方法A，如下图所示。"],
          "asset": "test_img1.png"
        }
      ]
    }
    
    # 创建一个用于测试的虚拟资产
    dummy_asset_dir = "output/test_assets"
    if not os.path.exists(dummy_asset_dir):
        os.makedirs(dummy_asset_dir)
    
    from PIL import Image
    img1 = Image.new('RGB', (800, 600), color = 'blue')
    img1.save(os.path.join(dummy_asset_dir, 'test_img1.png'))

    # 初始化生成器并创建PPT
    generator = PptGenerator(dummy_summary_with_assets, dummy_asset_dir)
    generator.create_presentation("output/test_presentation_with_assets.pptx")
