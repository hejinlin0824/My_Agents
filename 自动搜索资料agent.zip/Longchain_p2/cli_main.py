#agent入口

'''
todo:
    1.环境变量的设置
    2.工具的引入
    3.prompt模板
    4.模型的初始化
'''
import time
from tools import tools_map
from prompts import gen_prompt,user_prompt
from model_provider import ModelProvider
from dotenv import load_dotenv # 导入 load_dotenv

load_dotenv() # 调用 load_dotenv() 来加载 .env 文件



mp = ModelProvider()
def parse_thoughts(response):
    """
        response = {
            "action":{
                "name":"action_name",
                "args":{
                    "args name":"args value"
                }
            },
            "thoughts":
            {
                "text":"thought",
                "plan":"plan",
                "critic":"criticism",
                "speak":"当前展示给用户的信息",
                "reasoning":""
            }
        }
        
    """
    try:
        thoughts = response.get("thoughts")
        if not thoughts:
            return "（模型思考信息缺失）"
        
        # 提取各个思考部分，确保键名匹配
        plan = thoughts.get("plan", "无计划")
        criticism = thoughts.get("critic", "无批评") # 确保这里是 'critic'
        speak = thoughts.get("speak", "无输出给用户的信息")
        reasoning = thoughts.get("reasoning", "无推理")
        
        # 组合成一个清晰的思考记录
        return f"计划: {plan}\n推理: {reasoning}\n批评: {criticism}\n给用户: {speak}"
    except Exception as e:
        return f"（解析思考信息异常: {e}）" # 简化错误信息
    
def format_tool_output(tool_name, output):
    """根据工具名称和输出内容，进行格式化，使其更易读"""
    if tool_name == "search":
        # 假设搜索结果是多行字符串，我们尝试每行添加前缀
        lines = str(output).split('\n')
        formatted_lines = []
        for i, line in enumerate(lines):
            if line.strip(): # 避免空行
                formatted_lines.append(f"    - {line.strip()}") # 增加缩进和前缀
        return "\n".join(formatted_lines) if formatted_lines else "    （无有效搜索结果）"
    # 可以为其他工具添加更多格式化规则，例如文件读写
    return str(output) # 默认返回字符串形式的原始输出
# --- 辅助函数结束 ---


def agent_execute(querry,max_request_time = 10):
    cur_request_time = 0
    chat_history = []
    agent_scratch = '' # 用于累积 agent 的思考和工具执行结果

    print(f"\n======== 开始处理目标：【{querry}】 ========\n", flush=True)

    while cur_request_time < max_request_time:
        cur_request_time += 1
        
        # 仅在每次循环开始时打印当前轮次
        print(f"\n--- 第 {cur_request_time} 轮：模型思考与行动 ---", flush=True)

        prompt = gen_prompt(querry,agent_scratch)
        
        print(">> 正在调用大模型...", flush=True)
        start_time = time.time()
        response = mp.chat(prompt, chat_history)
        end_time = time.time()
        print(f"<< 大模型响应，耗时: {end_time - start_time:.2f} 秒", flush=True)

        if not response or not isinstance(response,dict):
            print("【错误】大模型返回结果异常或为空，重试中...", flush=True)
            continue
        
        action_info = response.get("action")
        thoughts = response.get("thoughts") # 获取模型的思考部分
        
        if not action_info or not thoughts:
            print("【错误】大模型返回结果缺少 'action' 或 'thoughts' 字段，重试中...", flush=True)
            continue

        action_name = action_info.get("name")
        action_args = action_info.get("args", {}) # 确保 args 默认为空字典，防止 NoneType 错误
        
        # 打印模型计划的动作和给用户的说法
        print(f"模型意图执行动作: 【{action_name}】", flush=True)
        if action_args:
            print(f"动作参数: {action_args}", flush=True)
        print(f"模型给用户的反馈: {thoughts.get('speak', '（无）')}", flush=True)


        if action_name == "finish":
            final_answer = action_args.get("answer", "未能提供最终答案。") # 如果没有 answer，给出默认值
            print(f"\n======== 任务完成！========\n最终答案：{final_answer}\n", flush=True)
            break # 任务完成，退出循环
        
        observation1 = "" # 存储工具执行后的结果
        try:
            func = tools_map.get(action_name)
            if func:
                print(f">> 正在执行工具: 【{action_name}】...", flush=True)
                # 确保参数正确传递，使用 **action_args
                observation1 = func(**action_args)
                # 格式化工具输出，使其更易读
                formatted_tool_output = format_tool_output(action_name, observation1)
                print(f"<< 工具 {action_name} 执行结果:\n{formatted_tool_output}", flush=True)
            else:
                observation1 = f"【错误】未知的工具: '{action_name}'。"
                print(observation1, flush=True) # 直接打印错误信息

        except Exception as e:
            # 捕获并打印工具执行时的具体异常
            observation1 = f"【错误】工具 '{action_name}' 调用异常：{e}"
            print(observation1, flush=True) # 打印工具调用异常信息


        # 构建 agent_scratch，包含模型在当前轮次的思考和工具输出
        # 这部分是给模型看的历史记录，需要清晰且有结构
        assistant_msg_for_scratch = parse_thoughts(response) # 获取模型对本轮的思考
        
        agent_scratch += f"\n--- 历史记录（轮次 {cur_request_time}）---\n"
        agent_scratch += f"模型思考: {assistant_msg_for_scratch}\n"
        agent_scratch += f"工具 {action_name} 的输出:\n{format_tool_output(action_name, observation1)}\n" # 使用格式化后的工具输出

        # 更新 chat_history，用于模型的对话上下文
        # user_prompt 应该改为当前轮次的用户实际查询 querry
        # assistant_msg 是模型给用户的“speak”内容
        chat_history.append([querry, thoughts.get('speak', '')]) # 将用户提问和模型的“speak”部分作为历史，而不是固定的user_prompt

    else: # 如果循环结束是因为达到了 max_request_time
        print(f"\n======== 达到最大请求次数 ({max_request_time}次)，任务终止。========\n", flush=True)

def main():
    #需求：支持用户的多次交互
    max_request_time=10
    while True:
        querry = input("请输入您的目标：")
        if querry =="exit":
            break
        agent_execute(querry,max_request_time = max_request_time)

if __name__ == "__main__":
    main()