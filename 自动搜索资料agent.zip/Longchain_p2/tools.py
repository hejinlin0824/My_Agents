'''
1.写文件
2.读文件
3.追加
4.网络搜索
'''
import os
import json
from langchain_tavily import TavilySearch 
def _get_workdir_root():
    workdir_root = os.environ.get('WORKDIR_ROOT', './data/llm_reasult')
    return workdir_root

WORKDIR_ROOT = _get_workdir_root

def read_file(file_name):
    if not os.path.exists(file_name):
        return f"文件不存在：{file_name}"
    else:
        with open(file_name,'r') as f:
            return "\n".join(f.readlines())
        
def append_to_file(file_name,content):
    filename = os.path.join(WORKDIR_ROOT(),file_name)
    if not os.path.join(WORKDIR_ROOT,filename):
        return f"文件不存在：{filename}"
    with open(filename,'a') as f:
        f.write(content)
    return f"已添加内容到文件：{filename}"

def write_to_file(filename,content):
    filename = os.path.join(WORKDIR_ROOT(),filename)
    if not os.path.exists(WORKDIR_ROOT):
        os.makedirs(WORKDIR_ROOT)
    with open(filename,'w') as f:
        f.write(content)
    return f"已写入内容到文件：{filename}"

def search(query):
    try:
        # 实例化 TavilySearch。它会自动从 TAVILY_API_KEY 环境变量中获取密钥
        tavily = TavilySearch(max_results=5) # 或者 TavilySearchResults，取决于你使用的是哪个
        ret = tavily.invoke(input=query)
        
        # 调试打印，用于查看 Tavily 返回的原始数据
        #print(f"DEBUG: Tavily invoke returned: {ret}, type: {type(ret)}")

        # 检查 ret 是否是一个字典，并且包含 'results' 键
        if isinstance(ret, dict) and 'results' in ret:
            search_results = ret['results'] # 获取包含搜索结果的列表

            if isinstance(search_results, list): # 确保 search_results 是一个列表
                content_list = []
                for obj in search_results: # 遍历搜索结果列表
                    if isinstance(obj, dict) and 'content' in obj:
                        content_list.append(obj['content'])
                
                if not content_list and search_results:
                    return f"搜索完成但未找到相关内容或格式异常: {search_results}"
                return "\n".join(content_list)
            else:
                return f"Tavily API 'results' 字段类型异常: {type(search_results)} -> {search_results}"
        elif isinstance(ret, str): # 如果返回的是字符串，可能是错误信息
            return f"Tavily API 错误信息: {ret}"
        else: # 其他未知类型，或者缺少 'results' 键
            return f"搜索API返回未知类型或缺少'results'键: {type(ret)} -> {ret}"

    except Exception as e:
        print(f"Tavily Search Exception: {e}") # 打印更具体的异常信息
        return "搜索失败"
    
tools_info = [
    {
        "name":"read_file",
        "description": "读取文件内容",
        "args":[{
            "name":"filename",
            "type":"string",
            "description": "获取文件名"

        }]
    },
    {
        "name":"append_to_file",
        "description": "追加内容到文件",
        "args":[{
            "name":"filename",
            "type":"string",
            "description": "获取文件名"
        },{
            "name":"content",
            "type":"string",
            "description": "获取内容"
        }]
    },
    {
        "name":"write_to_file",
        "description": "写入文件",
        "args":[{
            "name":"filename",
            "type":"string",
            "description": "获取文件名"
        },{
            "name":"content",
            "type":"string",
            "description": "获取内容"
        }]

    },
    {
        "name":"search",
        "description": "这是一个搜索引擎，当你没有在大模型中获取有用信息时候，就可以调用这个搜索引擎，输入你想搜索的内容，然后等待结果。",
        "args":[{
            "name":"query",
            "type":"string",
            "description": "输入你想搜索的内容"

        }]
    },
    {
        "name": "finish",
        "description": "当你已经完成了用户的目标，或者已经获得了足够的信息来回答用户的问题时，使用此动作来提供最终答案。",
        "args": [{
            "name": "answer",
            "type": "string",
            "description": "你对用户问题的最终答案"
        }]
    }
]

tools_map = {
    "read_file":read_file,
    "append_to_file":append_to_file,
    "search":search,
    "write_to_file":write_to_file
}

def gen_tools_desc():
    tools_desc = []
    for idx,t in enumerate(tools_info):
        args_desc = []
        for info in t['args']:
            args_desc.append({
                "name": info['name'],
                "description": info['description'],
                "type": info['type'],
            })
        args_desc = json.dumps(args_desc,ensure_ascii=False)
        tools_desc.append(f"{idx + 1}. {t['name']}: {t['description']},args: {args_desc}")
    tools_prompt = "\n".join(tools_desc)
    return tools_prompt