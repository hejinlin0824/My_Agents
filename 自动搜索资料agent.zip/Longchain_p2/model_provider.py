import dashscope
import os
from prompts import user_prompt
from dashscope.api_entities.dashscope_response import Message
import json # 确保导入 json 库

class ModelProvider(object):
    def __init__(self):
        self.api_key = os.environ.get("API_KEY")
        self.model_name = os.environ.get("MODEL_NAME")
        self.base_url = os.environ.get("BASE_URL")
        self._client = dashscope.Generation()
        self.max_retry_time = 3

    def chat(self,prompt,chat_history):
        cur_retry_time = 0
        while cur_retry_time < self.max_retry_time:
            cur_retry_time += 1
            try:
                messages = [{"role": "system", "content": prompt}]
                for his in chat_history:
                    messages.append(Message(role="user", content=his[0]))
                    messages.append(Message(role="assistant", content=his[1]))
                messages.append(Message(role="user",content=user_prompt))
                response = self._client.call(
                    model = self.model_name,
                    api_key = self.api_key,
                    messages = messages
                )
                print(f"DashScope Response: {response}") # 保留这行用于调试

                # 检查响应结构，并从 'text' 字段解析 JSON
                if response and "output" in response and "text" in response["output"]:
                    try:
                        # 尝试解析 text 字段中的 JSON 字符串
                        content_json = json.loads(response["output"]["text"])
                        # 这里返回解析后的字典，而不是直接的 content 字符串
                        return content_json
                    except json.JSONDecodeError as e:
                        print(f"Error decoding JSON from model response text: {e}")
                        return {} # 返回空字典表示解析失败
                else:
                    print("DashScope Response structure is unexpected or missing 'output' or 'text'.")
                    return {} # 返回空字典表示结构不符
            except Exception as e:
                print(f"Error calling DashScope API: {e}")
            return {}