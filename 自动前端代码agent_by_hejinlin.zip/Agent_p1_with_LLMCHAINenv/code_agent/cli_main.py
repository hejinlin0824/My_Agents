# cli_main.py

import time
import json
from dotenv import load_dotenv

# 导入我们项目的所有核心组件
from model_provider import ModelProvider
from tools import tools_map
from prompts import gen_prompt

# 加载 .env 文件中的环境变量 (例如 DASHSCOPE_API_KEY)
load_dotenv()

# --- 辅助函数，用于美化输出 ---
def parse_thoughts(response_dict):
    """格式化模型思考过程，使其易于阅读。"""
    if not isinstance(response_dict, dict) or "thoughts" not in response_dict:
        return "（模型思考信息缺失或格式错误）"
    
    try:
        thoughts = response_dict.get("thoughts", {})
        plan = thoughts.get("plan", "无计划")
        criticism = thoughts.get("critic", "无批评")
        speak = thoughts.get("speak", "无输出给用户的信息")
        reasoning = thoughts.get("reasoning", "无推理")
        
        return f"计划: {plan}\n推理: {reasoning}\n批评: {criticism}\n"
    except Exception as e:
        return f"（解析思考信息异常: {e}）"

# --- Agent 主执行函数 ---
def agent_execute(querry: str, max_request_time: int = 30):
    """
    Agent的主工作循环。
    :param querry: 用户的初始高级目标。
    :param max_request_time: 最大循环次数，防止无限循环。对于复杂项目，需要更多次循环。
    """
    
    # 1. 初始化
    cur_request_time = 0
    agent_scratch = ''  # Agent的“草稿纸”或“长期记忆”
    
    # 初始化模型提供商
    try:
        mp = ModelProvider()
    except Exception as e:
        print(f"致命错误：初始化ModelProvider失败: {e}")
        return

    print(f"\n======== 开始执行新目标：【{querry}】 ========\n")

    # 2. ReAct循环开始
    while cur_request_time < max_request_time:
        cur_request_time += 1
        print(f"\n--- 第 {cur_request_time}/{max_request_time} 轮：思考与行动 ---")

        # a. 思考阶段：构建完整的Prompt
        prompt = gen_prompt(querry, agent_scratch)
        
        # 将其格式化为模型提供商需要的消息列表格式
        messages = [{"role": "system", "content": "你是一个AI Agent，严格遵循system prompt中的所有指令。"}, {"role": "user", "content": prompt}]
        
        print(">> 正在调用大模型进行决策...")
        start_time = time.time()
        
        # b. 决策阶段：调用LLM获取下一步行动指令 (总是期望得到JSON)
        response_data = mp.chat(messages, parse_json=True)
        
        end_time = time.time()
        print(f"<< 大模型响应，耗时: {end_time - start_time:.2f} 秒")

        # c. 校验和解析模型的决策
        if not isinstance(response_data, dict) or "action" not in response_data:
            print("【错误】大模型返回结果不是有效的JSON指令或缺少'action'字段，重试中...")
            print(f"原始返回: {response_data}")
            agent_scratch += f"\n--- 历史记录（轮次 {cur_request_time}）---\n模型返回了无效指令，内容为：{response_data}\n"
            continue
        
        # 打印模型的思考过程和用户提示
        print(parse_thoughts(response_data))
        speak_to_user = response_data.get("thoughts", {}).get("speak", "")
        if speak_to_user:
            print(f"模型希望对你说: {speak_to_user}")

        action_info = response_data.get("action", {})
        action_name = action_info.get("name")
        action_args = action_info.get("args", {})
        
        print(f"\n模型决定执行动作: 【{action_name}】")
        if action_args:
            print(f"动作参数: {action_args}")

        # d. 行动阶段：执行工具
        if action_name == "finish":
            final_answer = action_args.get("answer", "任务已完成，但未提供最终总结。")
            print(f"\n======== 任务完成！========\n最终答案：{final_answer}\n")
            break

        observation = ""  # 存储工具执行结果
        if action_name in tools_map:
            try:
                func_to_run = tools_map[action_name]
                print(f">> 正在执行工具: 【{action_name}】...")
                observation = func_to_run(**action_args)
                print(f"<< 工具执行结果:\n{observation}")
            except Exception as e:
                observation = f"【错误】执行工具 '{action_name}' 时发生异常: {e}"
                print(observation)
        else:
            observation = f"【错误】意图执行未知的工具: '{action_name}'。"
            print(observation)

        # e. 记录阶段：更新“草稿纸”
        agent_scratch += f"\n--- 历史记录（轮次 {cur_request_time}）---\n"
        agent_scratch += f"模型思考:\n{parse_thoughts(response_data)}\n"
        agent_scratch += f"执行的动作: {action_name}\n"
        agent_scratch += f"动作的参数: {action_args}\n"
        agent_scratch += f"动作的观察结果:\n{observation}\n"

    else:  # 如果循环是因为次数用完而退出的
        print(f"\n======== 已达到最大请求次数 ({max_request_time}次)，任务自动终止。========\n")

# --- 程序主入口 ---
def main():
    """程序的主入口，负责与真实用户进行交互。"""
    print("欢迎使用前端项目架构师 Agent！")
    print("您可以输入一个高级目标，例如 '帮我设计一个电商网站'。")
    
    while True:
        querry = input("\n请输入您的目标 (输入 'exit' 退出): ")
        if querry.lower() == "exit":
            print("感谢使用，再见！")
            break
        if not querry.strip():
            print("请输入有效的目标。")
            continue
            
        agent_execute(querry)

if __name__ == "__main__":
    main()