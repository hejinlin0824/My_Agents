# tools.py

import os
import json

try:
    from model_provider import ModelProvider
except ImportError:
    print("错误：无法从 model_provider.py 导入 ModelProvider 类。请确保文件存在且类名正确。")
    ModelProvider = None

# --- 1. 全局模型实例和更新后的辅助函数 ---

# 将全局实例初始化为 None，我们将在第一次使用时才创建它
llm_provider = None

def _get_llm_provider():
    """
    获取LLM提供商的单例。如果尚未初始化，则创建它。
    这是一种“懒加载”模式，确保只有在需要时才初始化，
    并且此时环境变量已经被主程序加载。
    """
    global llm_provider
    if llm_provider is None:
        print("tools.py: 首次调用工具，正在初始化全局ModelProvider...")
        try:
            if ModelProvider:
                llm_provider = ModelProvider()
                print("tools.py: 全局ModelProvider 初始化成功。")
            else:
                print("警告 (tools.py): ModelProvider 未定义，基于LLM的工具将无法工作。")
        except Exception as e:
            print(f"警告 (tools.py): 全局ModelProvider 初始化失败。错误: {e}")
    return llm_provider

def _llm_call(prompt: str, system_prompt: str, parse_json: bool) -> (dict | str):
    """
    一个通用的辅助函数，用于调用大语言模型。
    它将 parse_json 参数直接传递给 model_provider 的 chat 方法。
    """
    provider = _get_llm_provider() # <-- 获取实例
    if not provider:
        return "错误：模型提供商未初始化，无法调用LLM。"
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": prompt}
    ]
    
    # 将 parse_json 参数传递给 chat 方法，让 model_provider 决定如何返回结果
    return provider.chat(messages, parse_json=parse_json)

# --- 2. 目录和文件操作工具 (无需改动) ---

def _get_workdir_root():
    workdir_root = os.path.join('./data', 'generated_websites')
    if not os.path.exists(workdir_root):
        os.makedirs(workdir_root)
    return workdir_root

def write_to_file(filename: str, content: str) -> str:
    """将内容写入文件，会自动创建必要的子目录。"""
    try:
        full_path = os.path.join(_get_workdir_root(), filename)
        directory = os.path.dirname(full_path)
        if not os.path.exists(directory):
            os.makedirs(directory)
        
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return f"成功将内容写入文件：{filename}"
    except Exception as e:
        return f"写入文件 '{filename}' 时发生错误: {e}"

def read_file(filename: str) -> str:
    """读取一个已存在文件的全部内容。"""
    try:
        full_path = os.path.join(_get_workdir_root(), filename)
        with open(full_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        return f"读取文件 '{filename}' 时发生错误: {e}"

def list_files(path: str = '.') -> str:
    """列出指定路径下的所有文件和文件夹。"""
    try:
        base_path = _get_workdir_root()
        target_path = os.path.normpath(os.path.join(base_path, path))
        
        # 安全检查，防止路径穿越
        if not os.path.abspath(target_path).startswith(os.path.abspath(base_path)):
            return "错误：禁止访问工作目录之外的路径。"

        if not os.path.exists(target_path):
            return f"错误：目录 '{path}' 不存在。"
            
        files = os.listdir(target_path)
        return "\n".join(files) if files else f"目录 '{path}' 是空的。"
    except Exception as e:
        return f"列出文件时发生错误: {e}"

# --- 3. 基于LLM的核心工具 (更新版) ---

def create_project_plan(project_description: str) -> str:
    """接收一个高级项目描述，通过调用LLM动态生成一个结构化的JSON计划。"""
    print(f"--- 正在调用LLM为 '{project_description}' 创建项目计划 ---")
    system_prompt = "你是一个经验丰富的前端架构师。你的任务是把用户的项目需求分解成一个结构清晰、可执行的JSON计划。JSON的key必须使用英文驼峰命名法。只输出JSON代码，不要有任何其他文字说明。"
    prompt = f"""
    请为以下项目需求创建一个详细的JSON计划：
    项目需求: "{project_description}"

    你的JSON输出必须包含以下key:
    - "projectName": 项目名称 (string)
    - "fileStructure": 一个包含所有文件和目录路径的列表 (list of strings)
    - "sharedComponents": 一个包含所有页面共享的组件名称的列表 (list of strings)
    - "pagePlan": 一个对象列表，每个对象描述一个页面的规划，包含 "file" (文件名) 和 "description" (页面的详细功能和布局描述) (list of objects)

    请确保JSON格式严格正确，不要包含任何多余的解释或Markdown的```标记。
    """
    # 调用辅助函数，明确要求返回解析后的JSON（字典）
    response = _llm_call(prompt, system_prompt, parse_json=True)
    
    # 检查返回的是否是字典且不包含错误信息
    if isinstance(response, dict) and "error" not in response:
        # Agent的观察结果(observation)应该是字符串，所以我们将验证过的字典转换回格式化的JSON字符串
        return json.dumps(response, indent=2, ensure_ascii=False)
    else:
        # 如果返回的是错误信息或不是字典，则返回一个清晰的错误字符串
        return f"错误：LLM未能返回有效的JSON计划。返回内容：\n{response}"

def generate_ui_code(component_description: str) -> str:
    """根据详细描述，通过调用LLM动态生成HTML/CSS/JS代码。"""
    print(f"--- 正在调用LLM生成UI代码：'{component_description}' ---")
    system_prompt = "你是一位顶级的Web前端开发专家，精通HTML5, CSS3和现代JavaScript。你的任务是根据用户的组件描述，生成高质量、干净、可直接使用的代码。你必须只输出纯代码，绝对不要包含任何额外的解释、介绍、注释或Markdown的```标记。"
    prompt = f"""
    请为以下描述生成相应的代码：
    组件或页面描述: "{component_description}"
    """
    # 调用辅助函数，明确要求返回原始文本字符串
    return _llm_call(prompt, system_prompt, parse_json=False)

# --- 4. 工具元数据定义 (无需改动) ---

tools_info = [
    {
        "name": "create_project_plan",
        "description": "用于处理'设计网站'等复杂请求的第一步。它能将模糊需求分解成一个结构化的JSON项目计划，此计划将指导后续所有工作。",
        "args": [{"name": "project_description", "type": "string", "description": "用户提出的原始、高级别的项目描述。"}]
    },
    {
        "name": "generate_ui_code",
        "description": "根据对UI组件或页面的详细文字描述，生成相应的HTML, CSS, 或JS代码片段。描述越具体，生成效果越好。",
        "args": [{"name": "component_description", "type": "string", "description": "例如：'一个现代风格的电商网站页头'或'全局CSS样式，包含主题色和字体定义'"}]
    },
    {
        "name": "list_files",
        "description": "列出当前工作目录或指定子目录中所有已生成的文件和文件夹。用于检查项目进度。",
        "args": [{"name": "path", "type": "string", "description": "要查看的相对路径，例如'.'代表根目录, 'assets/css'代表css目录。"}]
    },
    {
        "name": "write_to_file",
        "description": "将文本内容写入指定文件，如果文件已存在则覆盖。用于保存生成的代码。如果路径包含子目录，会自动创建。",
        "args": [
            {"name": "filename", "type": "string", "description": "要写入的文件相对路径，如 'index.html' 或 'assets/css/style.css'"},
            {"name": "content", "type": "string", "description": "要写入文件的代码或文本。"}
        ]
    },
    {
        "name": "read_file",
        "description": "读取一个已存在文件的全部内容。常用于修改已有代码或组合代码片段。",
        "args": [{"name": "filename", "type": "string", "description": "要读取的文件的相对路径。"}]
    },
    {
        "name": "finish",
        "description": "当你根据项目计划，完成了所有文件的生成和保存后，调用此动作来结束任务。",
        "args": [{"name": "answer", "type": "string", "description": "给用户的最终总结性答复，告诉他项目已完成及如何查看。"}]
    }
]

tools_map = {
    "create_project_plan": create_project_plan,
    "generate_ui_code": generate_ui_code,
    "list_files": list_files,
    "write_to_file": write_to_file,
    "read_file": read_file,
}

def gen_tools_desc():
    """将 tools_info 列表转换成对LLM友好的字符串格式。"""
    tools_desc_list = []
    for idx, t in enumerate(tools_info):
        args_desc = json.dumps(t['args'], ensure_ascii=False) 
        tools_desc_list.append(f"{idx + 1}. {t['name']}: {t['description']}, 参数: {args_desc}")
    return "\n".join(tools_desc_list)