# model_provider.py

import os
import json
import dashscope
from dashscope.api_entities.dashscope_response import Message

class ModelProvider:
    """
    负责与大语言模型（在此为DashScope的通义千问）进行所有通信。
    它封装了API密钥、网络请求、重试逻辑和响应解析，为上层应用提供一个干净的接口。
    """
    def __init__(self):
        """
        构造函数：当创建ModelProvider实例时，自动加载配置。
        """
        # 1. 从环境变量加载API密钥，这是管理敏感信息的最佳实践
        self.api_key = os.environ.get("DASHSCOPE_API_KEY")
        if not self.api_key:
            # 如果没有找到API Key，打印致命错误并退出，因为程序无法继续
            raise ValueError("错误：环境变量 DASHSCOPE_API_KEY 未设置。请先设置您的API Key。")

        # 2. 从环境变量加载模型名称，如果未设置，则使用'qwen-max'作为默认模型
        self.model_name = os.environ.get("MODEL_NAME")
        
        # 3. 初始化DashScope的客户端实例
        self._client = dashscope.Generation()
        
        # 4. 设置API调用失败时的最大重试次数
        self.max_retry_time = 3
        
        print(f"model_provider.py: ModelProvider已使用模型'{self.model_name}'初始化成功。")

    def chat(self, messages: list, parse_json: bool = True) -> (dict | str):
        """
        与大模型进行一次对话。

        :param messages: 一个符合DashScope格式的消息列表 (e.g., [{"role": "system", ...}, {"role": "user", ...}])
        :param parse_json: 一个布尔值，决定此方法是返回一个解析后的Python字典还是原始的文本字符串。
                           - True (默认): 尝试将模型的回复解析为JSON，返回一个字典。适用于需要结构化输出的场景（如主Agent的决策）。
                           - False: 直接返回模型回复的原始文本字符串。适用于需要纯文本或代码的场景（如生成UI代码）。
        :return: 根据 parse_json 的值，返回一个字典或字符串。
        """
        cur_retry_time = 0
        while cur_retry_time < self.max_retry_time:
            cur_retry_time += 1
            try:
                # 使用DashScope客户端发起API调用
                response = self._client.call(
                    model=self.model_name,
                    api_key=self.api_key,
                    messages=messages,
                    result_format='text'  # 我们总是请求文本格式的回复
                )

                # 检查API调用是否成功
                if response.status_code == 200:
                    raw_text = response.output.text
                    
                    if parse_json:
                        # 如果调用者期望得到JSON，我们尝试解析
                        try:
                            # 找到JSON对象的开始和结束位置，以去除可能的Markdown标记或其它污染
                            json_start = raw_text.find('{')
                            json_end = raw_text.rfind('}') + 1
                            if json_start != -1 and json_end != 0:
                                clean_json_str = raw_text[json_start:json_end]
                                return json.loads(clean_json_str)
                            else:
                                raise json.JSONDecodeError("在文本中未找到有效的JSON对象。", raw_text, 0)
                        except json.JSONDecodeError as e:
                            print(f"警告：期望得到JSON，但模型返回结果解析失败。错误: {e}")
                            print(f"原始返回文本: {raw_text}")
                            # 解析失败时返回一个包含错误信息的字典，让上层能处理
                            return {"error": "JSONDecodeError", "message": str(e), "raw_text": raw_text}
                    else:
                        # 如果调用者只想要原始文本，我们直接返回
                        return raw_text
                
                else:
                    # 如果API返回了错误状态码
                    print(f"错误：DashScope API 返回状态码 {response.status_code}, 消息: {response.message}")

            except Exception as e:
                # 捕获其他网络或程序异常
                print(f"错误：调用DashScope API时发生异常: {e}")
            
            # 如果发生错误，则等待片刻后重试
            print(f"API调用失败。正在重试... ({cur_retry_time}/{self.max_retry_time})")

        # 如果所有重试都失败了
        error_message = "错误：在多次重试后，仍无法从模型获取有效响应。"
        if parse_json:
            return {"error": "MaxRetriesExceeded", "message": error_message}
        else:
            return error_message